package net.stackmod;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SitCommand implements CommandExecutor {

    private final StackModPlugin plugin;

    public SitCommand(StackModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("This command is player-only.");
            return true;
        }
        if (!p.hasPermission("stackmod.admin")) {
            p.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("menu")) {
            plugin.getMenuManager().openMenu(p);
            return true;
        }
        if (args[0].equalsIgnoreCase("enable")) {
            plugin.getConfig().set("enabled", true);
            plugin.reloadSettings();
            p.sendMessage(ChatColor.GREEN + "StackMod enabled.");
            return true;
        }
        if (args[0].equalsIgnoreCase("disable")) {
            plugin.getConfig().set("enabled", false);
            plugin.reloadSettings();
            p.sendMessage(ChatColor.YELLOW + "StackMod disabled.");
            return true;
        }
        if (args[0].equalsIgnoreCase("toggle") && args.length >= 2) {
            String key = args[1];
            boolean val = !plugin.getConfig().getBoolean(key, false);
            plugin.getConfig().set(key, val);
            plugin.saveConfig();
            plugin.reloadSettings();
            p.sendMessage(ChatColor.AQUA + "Toggled " + key + " => " + val);
            return true;
        }
        if (args[0].equalsIgnoreCase("set") && args.length >= 3) {
            String key = args[1];
            try {
                int v = Integer.parseInt(args[2]);
                plugin.getConfig().set(key, v);
                plugin.saveConfig();
                plugin.reloadSettings();
                p.sendMessage(ChatColor.AQUA + "Set " + key + " => " + v);
            } catch (NumberFormatException ex) {
                p.sendMessage(ChatColor.RED + "Value must be an integer.");
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("info")) {
            Settings s = plugin.getSettings();
            p.sendMessage(ChatColor.GOLD + "StackMod Settings:");
            p.sendMessage(" enabled: " + s.enabled());
            p.sendMessage(" requireEmptyHand: " + s.requireEmptyHand());
            p.sendMessage(" requireSneak: " + s.requireSneak());
            p.sendMessage(" allowSitOnPlayers: " + s.allowSitOnPlayers());
            p.sendMessage(" allowSitOnStairs: " + s.allowSitOnStairs());
            p.sendMessage(" maxStackHeight: " + s.maxStackHeight());
            p.sendMessage(" preventAutoDismount: " + s.preventAutoDismount());
            return true;
        }
        p.sendMessage(ChatColor.YELLOW + "Usage: /sit [menu|enable|disable|toggle <key>|set <key> <value>|info]");
        return true;
    }
}
