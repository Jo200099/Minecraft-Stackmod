package net.stackmod;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class MenuManager implements Listener {

    private final StackModPlugin plugin;

    public MenuManager(StackModPlugin plugin) {
        this.plugin = plugin;
    }

    public void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, plugin.getSettings().menuTitle());
        inv.setItem(10, toggleItem("enabled", Material.LIME_DYE, plugin.getSettings().enabled()));
        inv.setItem(11, toggleItem("requireEmptyHand", Material.FEATHER, plugin.getSettings().requireEmptyHand()));
        inv.setItem(12, toggleItem("requireSneak", Material.LEATHER_BOOTS, plugin.getSettings().requireSneak()));
        inv.setItem(13, toggleItem("allowSitOnPlayers", Material.PLAYER_HEAD, plugin.getSettings().allowSitOnPlayers()));
        inv.setItem(14, toggleItem("allowSitOnStairs", Material.OAK_STAIRS, plugin.getSettings().allowSitOnStairs()));
        inv.setItem(15, toggleItem("preventAutoDismount", Material.ANVIL, plugin.getSettings().preventAutoDismount()));
        inv.setItem(16, valueItem("maxStackHeight", Material.PAPER, plugin.getSettings().maxStackHeight()));
        p.openInventory(inv);
    }

    private ItemStack toggleItem(String key, Material mat, boolean state) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + key + ChatColor.GRAY + " : " + (state ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF"));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack valueItem(String key, Material mat, int val) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + key + ChatColor.GRAY + " : " + ChatColor.GOLD + val);
        it.setItemMeta(meta);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        HumanEntity clicker = e.getWhoClicked();
        if (!(clicker instanceof Player p)) return;
        if (e.getView().getTitle() == null || !e.getView().getTitle().equals(plugin.getSettings().menuTitle())) return;
        e.setCancelled(true);
        if (e.getCurrentItem() == null) return;
        String name = e.getCurrentItem().getItemMeta() != null ? ChatColor.stripColor(e.getCurrentItem().getItemMeta().getDisplayName()) : null;
        if (name == null) return;

        String[] parts = name.split(" : ");
        if (parts.length < 1) return;
        String key = parts[0];

        switch (key) {
            case "enabled","requireEmptyHand","requireSneak","allowSitOnPlayers","allowSitOnStairs","preventAutoDismount" -> {
                boolean newVal = !plugin.getConfig().getBoolean(key, false);
                plugin.getConfig().set(key, newVal);
                plugin.saveConfig();
                plugin.reloadSettings();
                openMenu(p);
            }
            case "maxStackHeight" -> {
                int cur = plugin.getConfig().getInt("maxStackHeight", 0);
                int next = (cur >= 10) ? 0 : cur + 1; // cycle 0..10
                plugin.getConfig().set("maxStackHeight", next);
                plugin.saveConfig();
                plugin.reloadSettings();
                openMenu(p);
            }
            default -> {}
        }
    }
}
