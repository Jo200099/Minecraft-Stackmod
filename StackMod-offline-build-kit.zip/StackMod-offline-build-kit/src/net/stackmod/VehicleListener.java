package net.stackmod;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;

public class VehicleListener implements Listener {

    private final StackModPlugin plugin;

    public VehicleListener(StackModPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onVehicleEnter(VehicleEnterEvent e) {
        if (!(e.getEntered() instanceof Player p)) return;
        if (!plugin.getSettings().enabled()) return;
        if (p.isInsideVehicle() && plugin.getSettings().preventAutoDismount()) {
            // Prevent entering boats/minecarts while seated (avoid auto-dismount)
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onVehicleExit(VehicleExitEvent e) {
        if (!(e.getExited() instanceof Player p)) return;
        if (!plugin.getSettings().enabled()) return;
        if (plugin.getSitManager().shouldPreventDismount(p)) {
            e.setCancelled(true);
        }
    }
}
