package net.stackmod;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityToggleGlideEvent;

public class GlideListener implements Listener {

    private final StackModPlugin plugin;

    public GlideListener(StackModPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onToggleGlide(EntityToggleGlideEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (!plugin.getSettings().enabled()) return;
        if (p.isInsideVehicle() && plugin.getSettings().preventAutoDismount()) {
            // prevent glide toggling while seated to avoid dismounts
            e.setCancelled(true);
        }
    }
}
