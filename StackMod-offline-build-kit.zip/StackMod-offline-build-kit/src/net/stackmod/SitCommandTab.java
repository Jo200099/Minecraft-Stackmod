package net.stackmod;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SitCommandTab implements TabCompleter {

    private final StackModPlugin plugin;

    public SitCommandTab(StackModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            return Arrays.asList("menu", "enable", "disable", "toggle", "set", "info");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("toggle")) {
            return Arrays.asList("enabled","requireEmptyHand","requireSneak","allowSitOnPlayers","allowSitOnStairs","preventAutoDismount");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("set")) {
            return Arrays.asList("maxStackHeight");
        }
        return new ArrayList<>();
    }
}
