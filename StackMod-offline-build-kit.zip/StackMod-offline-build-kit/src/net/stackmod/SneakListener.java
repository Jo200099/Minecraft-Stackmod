package net.stackmod;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerToggleSneakEvent;

public class SneakListener implements Listener {

    private final StackModPlugin plugin;

    public SneakListener(StackModPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (!plugin.getSettings().enabled()) return;
        if (e.isSneaking()) {
            plugin.getSitManager().requestDismount(e.getPlayer());
        }
    }
}
