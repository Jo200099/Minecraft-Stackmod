package net.stackmod;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.util.Vector;

import java.util.*;

public class SitManager {

    private final StackModPlugin plugin;
    private final Map<UUID, ArmorStand> seatByPlayer = new HashMap<>(); // player -> seat
    private final Set<UUID> allowedDismountOnce = new HashSet<>(); // players allowed to dismount (sneak)

    public SitManager(StackModPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean canSitOnPlayers(Player p) {
        return plugin.getSettings().allowSitOnPlayers();
    }

    public boolean canSitOnStairs(Player p, Material clicked) {
        if (!plugin.getSettings().allowSitOnStairs()) return false;
        String name = clicked.name();
        return name.contains("STAIRS");
    }

    public boolean isEmptyHand(Player p) {
        if (!plugin.getSettings().requireEmptyHand()) return true;
        return (p.getInventory().getItemInMainHand().getType() == Material.AIR);
    }

    public boolean isRequireSneak(Player p) {
        return plugin.getSettings().requireSneak();
    }

    public int currentStackHeight(Entity e) {
        int h = 1;
        Entity cur = e;
        while (cur.getPassengers() != null && !cur.getPassengers().isEmpty()) {
            cur = cur.getPassengers().get(0);
            h++;
            if (h > 256) break; // sanity
        }
        return h;
    }

    public boolean withinMaxStack(Entity base) {
        int max = plugin.getSettings().maxStackHeight();
        if (max <= 0) return true;
        return currentStackHeight(base) < max;
    }

    public boolean sitOnPlayer(Player rider, Player base) {
        if (!plugin.getSettings().enabled()) return false;
        if (!canSitOnPlayers(rider)) return false;
        if (!isEmptyHand(rider)) return false;
        if (isRequireSneak(rider) && !rider.isSneaking()) return false;
        if (!withinMaxStack(base)) return false;

        boolean ok = base.addPassenger(rider);
        return ok;
    }

    public boolean sitOnStairs(Player rider, Location seatLoc) {
        if (!plugin.getSettings().enabled()) return false;
        if (!isEmptyHand(rider)) return false;
        if (isRequireSneak(rider) && !rider.isSneaking()) return false;

        ArmorStand seat = spawnSeat(seatLoc);
        if (seat == null) return false;
        if (!seat.addPassenger(rider)) {
            seat.remove();
            return false;
        }
        seatByPlayer.put(rider.getUniqueId(), seat);
        return true;
    }

    private ArmorStand spawnSeat(Location loc) {
        World w = loc.getWorld();
        if (w == null) return null;
        Location seatLoc = loc.clone().add(0.5, 0.0, 0.5);
        ArmorStand as = w.spawn(seatLoc, ArmorStand.class, st -> {
            st.setVisible(false);
            st.setMarker(true);
            st.setSmall(true);
            st.setGravity(false);
            st.setInvulnerable(true);
            st.setSilent(true);
            st.setCollidable(false);
            st.getEquipment().clear();
            st.addScoreboardTag("stackmod-seat");
        });
        return as;
    }

    public void requestDismount(Player p) {
        allowedDismountOnce.add(p.getUniqueId());
        if (p.isInsideVehicle()) {
            p.leaveVehicle();
        }
        ArmorStand seat = seatByPlayer.remove(p.getUniqueId());
        if (seat != null && !seat.getPassengers().contains(p)) {
            Bukkit.getScheduler().runTaskLater(plugin, seat::remove, 1L);
        }
        allowedDismountOnce.remove(p.getUniqueId());
    }

    public boolean shouldPreventDismount(Player p) {
        if (!plugin.getSettings().preventAutoDismount()) return false;
        return !allowedDismountOnce.contains(p.getUniqueId());
    }

    public void cleanupAllSeats() {
        for (ArmorStand as : seatByPlayer.values()) {
            try { as.remove(); } catch (Exception ignored) {}
        }
        seatByPlayer.clear();
    }
}
