package net.stackmod;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public class InteractListener implements Listener {

    private final StackModPlugin plugin;

    public InteractListener(StackModPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteractEntity(PlayerInteractAtEntityEvent e) {
        Player p = e.getPlayer();
        if (!plugin.getSettings().enabled()) return;
        if (e.getRightClicked() instanceof Player target) {
            boolean ok = plugin.getSitManager().sitOnPlayer(p, target);
            if (ok) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        if (!plugin.getSettings().enabled()) return;
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getClickedBlock() == null) return;
        Player p = e.getPlayer();
        Block b = e.getClickedBlock();
        Material m = b.getType();

        // Sit on stairs
        if (plugin.getSitManager().canSitOnStairs(p, m)) {
            Location seatLoc = b.getLocation().add(0, 0.4, 0); // small height offset
            boolean ok = plugin.getSitManager().sitOnStairs(p, seatLoc);
            if (ok) {
                e.setCancelled(true);
            }
        }
    }
}
