package net.stackmod;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public final class StackModPlugin extends JavaPlugin {

    private static StackModPlugin instance;
    private Settings settings;
    private SitManager sitManager;
    private MenuManager menuManager;

    public static StackModPlugin get() { return instance; }
    public Settings getSettings() { return settings; }
    public SitManager getSitManager() { return sitManager; }
    public MenuManager getMenuManager() { return menuManager; }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        reloadSettings();
        this.sitManager = new SitManager(this);
        this.menuManager = new MenuManager(this);

        // Register commands & listeners
        getCommand("sit").setExecutor(new SitCommand(this));
        getCommand("sit").setTabCompleter(new SitCommandTab(this));

        Bukkit.getPluginManager().registerEvents(new InteractListener(this), this);
        Bukkit.getPluginManager().registerEvents(new SneakListener(this), this);
        Bukkit.getPluginManager().registerEvents(new VehicleListener(this), this);
        Bukkit.getPluginManager().registerEvents(new GlideListener(this), this);
        Bukkit.getPluginManager().registerEvents(menuManager, this);

        getLogger().info("StackMod enabled.");
    }

    @Override
    public void onDisable() {
        if (sitManager != null) sitManager.cleanupAllSeats();
        getLogger().info("StackMod disabled.");
    }

    public void reloadSettings() {
        reloadConfig();
        FileConfiguration cfg = getConfig();
        this.settings = Settings.fromConfig(cfg);
    }
}
