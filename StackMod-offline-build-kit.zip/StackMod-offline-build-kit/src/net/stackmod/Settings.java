package net.stackmod;

import org.bukkit.configuration.file.FileConfiguration;

public record Settings(
        boolean enabled,
        boolean requireEmptyHand,
        boolean requireSneak,
        boolean allowSitOnPlayers,
        boolean allowSitOnStairs,
        int maxStackHeight,
        boolean preventAutoDismount,
        String menuTitle
) {
    public static Settings fromConfig(FileConfiguration cfg) {
        return new Settings(
                cfg.getBoolean("enabled", true),
                cfg.getBoolean("requireEmptyHand", true),
                cfg.getBoolean("requireSneak", true),
                cfg.getBoolean("allowSitOnPlayers", true),
                cfg.getBoolean("allowSitOnStairs", true),
                cfg.getInt("maxStackHeight", 0),
                cfg.getBoolean("preventAutoDismount", true),
                cfg.getString("menuTitle", "StackMod Settings")
        );
    }
}
